#!/usr/bin/env bash
export FLASK_APP=weather_app.py

flask run